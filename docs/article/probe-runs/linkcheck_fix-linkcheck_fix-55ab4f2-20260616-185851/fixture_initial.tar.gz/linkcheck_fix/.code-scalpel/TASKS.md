## [✓] T001: Создать README.md с описанием проекта

Goal: Документировать утилиту для поиска и проверки ссылок в .md файлах
Files: README.md
Acceptance:
- derived-acceptance:{"applicable": false, "args": "", "expected": ""}
Test command: manual

## [✓] T002: Инициализировать окружение Python

Goal: Создать файл pyproject.toml, настроить виртуальное окружение и установить зависимости
Files: pyproject.toml, .gitignore
Skills: python
Acceptance:
- pyproject.toml существует и содержит зависимости (requests, beautifulsoup4 или markdown)
- Виртуальное окружение создано и зависимости установлены
Test command: manual

## T003: Реализовать поиск .md файлов и извлечение ссылок

Goal: Написать скрипт, который рекурсивно находит все .md файлы и извлекает из них URL-ссылки
Files: link_checker.py
Skills: python
Acceptance:
- derived-acceptance:{"applicable": true, "args": "", "expected": ".md"}
Test command: `python link_checker.py --extract`

## T004: Реализовать проверку ссылок на доступность

Goal: Добавить в скрипт верификацию ссылок через HTTP-запросы (HEAD/GET) и вывод битых ссылок
Files: link_checker.py
Skills: python
Acceptance:
- derived-acceptance:{"applicable": true, "args": "test_links.txt", "expected": ""}
Test command: `python link_checker.py --check`

## T005: Запустить проверку всех .md файлов и вывести отчёт

Goal: Выполнить скрипт на проекте и вывести результаты проверки ссылок
Skills: python
Acceptance:
- derived-acceptance:{"applicable": true, "args": "", "expected": ""}
Test command: `python link_checker.py --check 2>&1 | tee report.txt`
