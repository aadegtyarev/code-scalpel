---
name: python-official-documentation
load: lazy
keywords: ["docs", "documentation", "pep", "python-doc"]
file_patterns: ["*.py", "*.rst", "*.md"]
test_cmd: ["python", "-m", "pytest"]
lint_cmds: [["ruff", "check", "."]]
allowed_commands: ["python", "pip", "pytest", "ruff", "git", "curl"]
---

# python-official-documentation
- Python 3.x docs live at `docs.python.org/3/` — subdivisions: Tutorial, Library Reference, Language Reference, HOWTOs, Glossary.
- PEP Index is at `peps.python.org` — canonical source for Python Enhancement Proposals (new features, process changes, style guides like PEP 8).
- `docs.python.org/3/py-modindex.html` — module index (quick lookup for standard library modules).
- Porting from Python 2 → 3: see `docs.python.org/3/howto/pyporting.html`.
- In-development docs: `docs.python.org/dev/`.
- Developer's Guide: `devguide.python.org` — how to contribute to CPython itself (patch workflow, testing, CI).
- Issue tracker: `github.com/python/cpython/issues` — all CPython bugs and feature requests.
- Docs are also downloadable in multiple formats from `docs.python.org/3/download.html`.
- Python Packaging User Guide: `packaging.python.org` — authoritative guide for packaging and distribution (pyproject.toml, setuptools, wheels).
- Beginner's Guide: `wiki.python.org/moin/BeginnersGuide` — curated starting points for new Python users.
- Python Books: `wiki.python.org/moin/PythonBooks` — community-maintained list of Python books.
- Non-English Docs: `translations.python.org` — localized Python documentation.
- Python Videos: `pyvideo.org` — conference talks and tutorials.
- Python Periodicals: `wiki.python.org/moin/PythonPeriodicals` — newsletters and magazines.
- Guido's Essays: `python.org/doc/essays/` — historical design essays by the BDFL.
- Use `python -c "import sys; print(sys.version)"` to verify runtime version before consulting version-specific docs.
